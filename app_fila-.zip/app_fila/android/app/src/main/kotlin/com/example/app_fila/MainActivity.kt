package com.example.app_fila

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
